<?php
$conn=mysqli_connect('localhost','root','','aplikasi_pengaduan');
?>