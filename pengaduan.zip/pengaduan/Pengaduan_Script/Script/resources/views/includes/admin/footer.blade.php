<footer class="mt-3 p-3 text-center bg-white text-sm text-gray-600 dark:text-gray-400 dark:bg-gray-800">
  © 2021 PENGKAT | By
  <a href="https://madfariz.web.id/" class="text-blue-500" target="_blank">MadFariz</a>
</footer>