<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo e(asset('./assets/css/tailwind.output.css')); ?>" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.css" />
<link rel="icon" href="<?php echo e(asset('img/favicon.svg')); ?>"><?php /**PATH E:\xampp\htdocs\pengaduan\resources\views/includes/admin/style.blade.php ENDPATH**/ ?>